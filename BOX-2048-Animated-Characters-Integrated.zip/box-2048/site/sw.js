// BOX 2048 service worker: works offline after the first visit
const CACHE = "box2048-v3-characters";
const CORE = ["./","index.html","manifest.webmanifest","logo.svg","icon-192.png","icon-512.png","icon-maskable-512.png","favicon.png","apple-touch-icon.png","assets/characters/character_01/idle.gif","assets/characters/character_01/celebrate.gif","assets/characters/character_01/unlock.gif","assets/characters/character_01/preview.png","assets/characters/character_02/idle.gif","assets/characters/character_02/celebrate.gif","assets/characters/character_02/unlock.gif","assets/characters/character_02/preview.png","assets/characters/character_03/idle.gif","assets/characters/character_03/celebrate.gif","assets/characters/character_03/unlock.gif","assets/characters/character_03/preview.png","assets/characters/character_04/idle.gif","assets/characters/character_04/celebrate.gif","assets/characters/character_04/unlock.gif","assets/characters/character_04/preview.png","assets/characters/character_05/idle.gif","assets/characters/character_05/celebrate.gif","assets/characters/character_05/unlock.gif","assets/characters/character_05/preview.png","assets/characters/character_06/idle.gif","assets/characters/character_06/celebrate.gif","assets/characters/character_06/unlock.gif","assets/characters/character_06/preview.png","assets/characters/character_07/idle.gif","assets/characters/character_07/celebrate.gif","assets/characters/character_07/unlock.gif","assets/characters/character_07/preview.png","assets/characters/character_08/idle.gif","assets/characters/character_08/celebrate.gif","assets/characters/character_08/unlock.gif","assets/characters/character_08/preview.png","assets/characters/character_09/idle.gif","assets/characters/character_09/celebrate.gif","assets/characters/character_09/unlock.gif","assets/characters/character_09/preview.png","assets/characters/character_10/idle.gif","assets/characters/character_10/celebrate.gif","assets/characters/character_10/unlock.gif","assets/characters/character_10/preview.png"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  const u = new URL(e.request.url);
  if (u.origin !== location.origin) return;
  e.respondWith(
    fetch(e.request).then((r) => { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); return r; })
      .catch(() => caches.match(e.request).then((m) => m || caches.match("index.html")))
  );
});
