# BOX 2048 — GitHub Android Release

این بسته شامل بازی BOX 2048، فایل‌های Worker و Workflow ساخت APK نسخه Release امضاشده است.

## ساختار
- `.github/workflows/build-apk.yml` — ساخت APK امضاشده و انتشار خودکار در GitHub Releases
- `box-2048/site/` — فایل‌های بازی
- `box-2048/android-res/` — آیکون‌های اندروید
- `box-2048/worker/worker.js` — Cloudflare Worker برای میزبانی نسخه وب بازی

## تنظیم اولیه GitHub
1. تمام محتویات این ZIP را در ریشه یک مخزن GitHub آپلود کن؛ پوشه `.github` باید مستقیماً در ریشه مخزن باشد.
2. در مخزن، به Settings → Secrets and variables → Actions → New repository secret برو.
3. چهار Secret زیر را دقیقاً با همین نام بساز:
   - `ANDROID_KEYSTORE_BASE64`
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
4. روش ساخت keystore و مقداردهی امن Secretها در راهنمای گفتگو توضیح داده شده است.
5. از Actions → Build BOX 2048 Android Release → Run workflow اجرا کن؛ یا یک Tag با الگوی `v*` منتشر کن.
6. APK امضاشده در Releases و Artifacts قرار می‌گیرد.

## شناسه برنامه
`com.sevenbox.box2048`

## فونت
بازی از Poppins با وزن‌های 500، 700 و 800 استفاده می‌کند. برای عنوان لوگویی از وزن 800 و برای عبارت BY 7BOX از وزن 700 با فاصله حروف بیشتر استفاده شده است.

## Cloudflare Worker
Worker موجود در `box-2048/worker/worker.js` نسخه وب بازی را از `worker/site.zip` سرو می‌کند. این Worker سازنده APK نیست؛ ساخت APK توسط GitHub Actions و فایل Workflow بالا انجام می‌شود.
