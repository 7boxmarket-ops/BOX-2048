# BOX 2048 Android

Native Android shell for the original `box-2048/site` game. The web game is copied unchanged to
`app/src/main/assets/site` and loaded locally by `MainActivity` in Android WebView.

- Application ID: `com.sevenbox.box2048`
- Display name: `BOX 2048`
- Minimum Android: 6.0 (API 23)
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

Build a debug APK with:

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.
