# BOX 2048

A smooth, colorful 2048 puzzle game. Created & developed by 7BOX.

```
box-2048/
├─ site/            the game (open site/index.html, or host the folder anywhere)
│  ├─ index.html    game, splash screen, logo, footer
│  ├─ manifest.webmanifest, sw.js   installable + works offline (PWA)
│  └─ logo.svg, icon-*.png, favicon.png, apple-touch-icon.png
├─ worker/          Cloudflare Worker named "box-2048"
│  ├─ worker.js     serves the game from site.zip, extracting it automatically
│  ├─ wrangler.toml
│  └─ site.zip      the zipped contents of site/
├─ logo.png / logo.svg   app logo
└─ tools/render_logo.py  regenerates the PNG icons from the logo design
```

## Run the Worker
```
npm install
npm run dev       # local test
npm run deploy    # zips site/ into worker/site.zip, then deploys "box-2048"
```
Edit anything in `site/`, run `npm run deploy`, done.

### How the automatic extraction works
`worker.js` bundles `site.zip`, reads its directory on the first request, inflates every file
(with the built-in `DecompressionStream`) and keeps them in memory. Requests are then answered
straight from memory with the right content types. No dependencies.

### Update without redeploying (optional)
Create an R2 bucket, upload a new `site.zip`, and add the `SITE` binding shown (commented) in
`wrangler.toml`. The Worker checks it about once a minute and re-extracts it by itself.

## GitHub Pages
Push to `main` and the included workflow publishes `site/` at `https://<user>.github.io/<repo>/`.
In the repo: Settings > Pages > Source: **GitHub Actions** (one time).

## Android APK (built by GitHub, no Android Studio needed)
1. Put `box-2048-project.zip` in the root of a GitHub repo (no need to extract it).
2. Add `.github/workflows/build-apk.yml` (included in this zip).
3. Open the Actions tab: "Build Android APK" extracts the zip by itself, wraps the game with
   Capacitor and builds `BOX-2048.apk`. Download it from the repo's **Releases** and install it.
The app id is `com.sevenbox.box2048`. Launcher icons come from `android-res/`.
The build is debug-signed, which is fine for installing on your own phone.
