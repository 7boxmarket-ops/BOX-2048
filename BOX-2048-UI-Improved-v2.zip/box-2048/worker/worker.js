// BOX 2048 - Cloudflare Worker that serves the game straight from site.zip.
// The zip is bundled with the Worker (see wrangler.toml) and is extracted
// automatically the first time the Worker runs. No dependencies needed.
//
// Optional: bind an R2 bucket named SITE and upload a new "site.zip" to it.
// The Worker notices the change within a minute and re-extracts it on its own,
// so you can update the game without redeploying.

import siteZip from "./site.zip";

const MIME = {
  html: "text/html; charset=utf-8", css: "text/css; charset=utf-8", js: "text/javascript; charset=utf-8",
  json: "application/json; charset=utf-8", webmanifest: "application/manifest+json; charset=utf-8",
  svg: "image/svg+xml", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp",
  gif: "image/gif", ico: "image/x-icon", txt: "text/plain; charset=utf-8", map: "application/json",
  woff2: "font/woff2", woff: "font/woff", mp3: "audio/mpeg", ogg: "audio/ogg", wav: "audio/wav",
};

async function inflateRaw(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

// Minimal ZIP reader (stored + deflate entries).
async function unzip(buffer) {
  const u8 = new Uint8Array(buffer);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let e = u8.length - 22;
  while (e >= 0 && dv.getUint32(e, true) !== 0x06054b50) e--;
  if (e < 0) throw new Error("not a zip file");
  const count = dv.getUint16(e + 10, true);
  let p = dv.getUint32(e + 16, true);
  const td = new TextDecoder();
  const files = new Map();
  for (let i = 0; i < count; i++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("corrupt zip directory");
    const flags = dv.getUint16(p + 8, true);
    const method = dv.getUint16(p + 10, true);
    const csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true);
    const xlen = dv.getUint16(p + 30, true);
    const clen = dv.getUint16(p + 32, true);
    const off = dv.getUint32(p + 42, true);
    const name = td.decode(u8.subarray(p + 46, p + 46 + nlen));
    p += 46 + nlen + xlen + clen;
    if (name.endsWith("/") || (flags & 1)) continue;
    if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store") || name.split("/").includes("..")) continue;
    if (csize === 0xffffffff) throw new Error("zip64 is not supported");
    const start = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true);
    const data = u8.subarray(start, start + csize);
    let bytes = null;
    if (method === 0) bytes = data;
    else if (method === 8) bytes = await inflateRaw(data);
    if (bytes) files.set(name.replace(/^\/+/, ""), bytes);
  }
  return stripRoot(files);
}

// If everything sits inside one top-level folder, serve that folder as the site root.
function stripRoot(files) {
  const names = [...files.keys()];
  if (!names.length) return files;
  const first = names[0].split("/")[0];
  if (!names.every((n) => n.includes("/") && n.split("/")[0] === first)) return files;
  const out = new Map();
  for (const [n, b] of files) out.set(n.slice(first.length + 1), b);
  return out;
}

const cache = { files: null, etag: null, checked: 0 };

async function getFiles(env) {
  const now = Date.now();
  if (cache.files && now - cache.checked < 60000) return cache.files;
  cache.checked = now;
  if (env.SITE) {
    const head = await env.SITE.head("site.zip");
    if (head) {
      if (!cache.files || cache.etag !== head.etag) {
        const obj = await env.SITE.get("site.zip");
        cache.files = await unzip(await obj.arrayBuffer());
        cache.etag = head.etag;
      }
      return cache.files;
    }
  }
  if (!cache.files || cache.etag !== "bundled") {
    cache.files = await unzip(siteZip);
    cache.etag = "bundled";
  }
  return cache.files;
}

export default {
  async fetch(request, env) {
    if (request.method !== "GET" && request.method !== "HEAD") {
      return new Response("Method Not Allowed", { status: 405, headers: { Allow: "GET, HEAD" } });
    }
    let files;
    try { files = await getFiles(env); }
    catch (err) { return new Response("Site archive could not be read: " + err.message, { status: 500 }); }

    let path;
    try { path = decodeURIComponent(new URL(request.url).pathname); }
    catch { return new Response("Bad request", { status: 400 }); }
    path = path.replace(/^\/+/, "");
    if (path === "" || path.endsWith("/")) path += "index.html";
    let bytes = files.get(path);
    if (!bytes && !/\.[a-z0-9]+$/i.test(path)) { path += "/index.html"; bytes = files.get(path); }
    if (!bytes) return new Response("Not found", { status: 404, headers: { "content-type": "text/plain; charset=utf-8" } });

    const ext = path.split(".").pop().toLowerCase();
    const live = /(^|\/)(index\.html|sw\.js|manifest\.webmanifest)$/.test(path);
    const headers = {
      "content-type": MIME[ext] || "application/octet-stream",
      "content-length": String(bytes.length),
      "cache-control": live ? "no-cache" : "public, max-age=86400",
      "x-content-type-options": "nosniff",
      "referrer-policy": "strict-origin-when-cross-origin",
    };
    return new Response(request.method === "HEAD" ? null : bytes, { headers });
  },
};
