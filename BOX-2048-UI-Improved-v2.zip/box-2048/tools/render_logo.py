import numpy as np
from PIL import Image, ImageDraw

def hexrgb(h): h=h.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))

def lin(w,h,p1,p2,c0,c1):
    # objectBoundingBox linear gradient over a w*h region
    u=(np.arange(w)+.5)/w; v=(np.arange(h)+.5)/h
    U,V=np.meshgrid(u,v)
    dx,dy=p2[0]-p1[0],p2[1]-p1[1]
    t=np.clip(((U-p1[0])*dx+(V-p1[1])*dy)/(dx*dx+dy*dy),0,1)[...,None]
    a=np.array(hexrgb(c0),float); b=np.array(hexrgb(c1),float)
    return (a+(b-a)*t).astype(np.uint8)

def render(S, maskable=False, m=1.0, ss=2, fg=False):
    W=S*ss; k=W/64.0
    mm = m
    def P(x,y):
        x=32+(x-32)*mm; y=32+(y-32)*mm
        return (x*k,y*k)
    # background
    base=Image.new('RGBA',(W,W),(0,0,0,0)) if fg else Image.fromarray(lin(W,W,(0,0),(1,1),'#2a2f3a','#0c0d10')).convert('RGBA')
    # glow
    yy,xx=np.mgrid[0:W,0:W]
    cx,cy=P(32,38); r=28*mm*k
    d=np.sqrt((xx+.5-cx)**2+(yy+.5-cy)**2)/r
    alpha=np.clip(1-d,0,1)*.55
    g=Image.new('RGBA',(W,W),hexrgb('#55c1f6')+(0,))
    g.putalpha(Image.fromarray((alpha*255).astype(np.uint8)))
    base=base if fg else Image.alpha_composite(base,g)
    if not maskable and not fg:
        mask=Image.new('L',(W,W),0)
        ImageDraw.Draw(mask).rounded_rectangle([0,0,W-1,W-1],radius=15*k,fill=255)
        base.putalpha(mask)
        # border
        bm=Image.new('L',(W,W),0)
        ImageDraw.Draw(bm).rounded_rectangle([1*k,1*k,63*k,63*k],radius=14*k,outline=255,width=int(2*k))
        bm=bm.point(lambda v:int(v*.18))
        base.paste((255,255,255,255),mask=bm)
    def stroke(pts,alpha,wd,closed=True):
        sm=Image.new('L',(W,W),0)
        pp=[P(*p) for p in pts]+([P(*pts[0])] if closed else [])
        dr=ImageDraw.Draw(sm); dr.line(pp,fill=255,width=max(1,int(wd*mm*k)),joint='curve')
        rr=wd*mm*k/2
        for (x,y) in pp: dr.ellipse([x-rr,y-rr,x+rr,y+rr],fill=255)
        sm=sm.point(lambda v:int(v*alpha))
        base.paste((255,255,255,255),mask=sm)
    def poly(pts,p1,p2,c0,c1,sa=None,sw=None):
        pp=[P(*p) for p in pts]
        xs=[p[0] for p in pp]; ys=[p[1] for p in pp]
        x0,y0,x1,y1=int(min(xs)),int(min(ys)),int(max(xs))+1,int(max(ys))+1
        w,h=x1-x0,y1-y0
        img=Image.fromarray(lin(w,h,p1,p2,c0,c1)).convert('RGBA')
        mk=Image.new('L',(w,h),0)
        ImageDraw.Draw(mk).polygon([(x-x0,y-y0) for x,y in pp],fill=255)
        base.paste(img,(x0,y0),mk)
        if sa: stroke(pts,sa,sw)
    poly([(16,28),(32,37),(32,57),(16,47)],(0,0),(0,1),'#ffbc47','#ee4b2b',.6,.9)
    poly([(32,37),(48,28),(48,47),(32,57)],(0,0),(0,1),'#f15596','#852dd2',.6,.9)
    poly([(32,19),(48,28),(32,37),(16,28)],(0,0),(1,1),'#a5eefd','#3cddb4',.6,.9)
    # the "7" mapped onto the pink face
    seven=[(1.5,1.55),(8.5,1.55),(8.5,3.25),(4.9,12.05),(2.7,12.05),(6.3,3.55),(1.5,3.55)]
    pts=[(1.6*x+32,-0.9*x+1.4286*y+37) for x,y in seven]
    ImageDraw.Draw(base).polygon([P(*p) for p in pts],fill=(255,255,255,255))
    # crown
    crown=[(23,15),(24.5,6.5),(28.5,10.5),(32,5),(35.5,10.5),(39.5,6.5),(41,15)]
    poly(crown,(0,0),(0,1),'#fff0a0','#ffb300',.7,.8)
    dr=ImageDraw.Draw(base)
    for (x,y) in [(24.5,5.8),(32,4.3),(39.5,5.8)]:
        cx_,cy_=P(x,y); rr=1.2*mm*k
        dr.ellipse([cx_-rr,cy_-rr,cx_+rr,cy_+rr],fill=(255,255,255,255))
    return base.resize((S,S),Image.LANCZOS)

import sys
out='site/'
render(1024).save('logo.png')
render(512).save(out+'icon-512.png')
render(192).save(out+'icon-192.png')
render(512,maskable=True,m=.78).convert('RGB').save(out+'icon-maskable-512.png')
render(180,maskable=True,m=.88).convert('RGB').save(out+'apple-touch-icon.png')
render(48).save(out+'favicon.png')
print('done')
